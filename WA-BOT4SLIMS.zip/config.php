<?php
//BOT WHATSAPP FOR SLIMS
//Create by : MASBUDIKUSUMA
//Email : masbudikusuma@gmail.com
//Website : https://sites.google.com/view/masbudikusuma/product/wa-bot-slims-library
//Release : 20 September 2021
$APIKEY = 'xxxxxxxxxxxxx'; // Please replace Your API KEY for security
$dbjoin = 'no'; //DB WEB Server BOT jadi 1 dengan SLIM Atau Terpisah, 'yes' or 'no'
$nomoradmin = "6281217181715"; // NOMOR WA ADMIN format internatioal 62,
$web = ""; //web SLIMS
date_default_timezone_set('Asia/Jakarta');
// Konfigurasi Database
if ($dbjoin == 'no'){ //Konfigurasi jika Server WABOT dan SLIM Terpisah
    $db_server   = "localhost";
    $db_username = "root";
    $db_password = "database123";
    $db_database = "wa-checkbot";
    $db = mysqli_connect($db_server,$db_username,$db_password,$db_database);
    // Konfigurasi Database
    $slims_server   = "";
    $slims_username = "";
    $slims_password = "";
    $slims_database = "";
    $slims = mysqli_connect($slims_server,$slims_username,$slims_password,$slims_database);
}
else if ($dbjoin == 'yes'){ //Konfigurasi jika Server WABOT dan SLIM jadi satu
    $slims_server   = "";
    $slims_username = "";
    $slims_password = "";
    $slims_database = "";
    $db = $slims = mysqli_connect($slims_server,$slims_username,$slims_password,$slims_database);
}


?>
