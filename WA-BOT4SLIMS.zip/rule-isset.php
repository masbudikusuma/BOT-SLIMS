<?php
if (isset($key[0])){
   $key1=$key[0];                                  //Kunci Pertama
   $key1 = preg_replace("/[^a-z0-9]/", "", $key1); //hanya karakter a-z
} else {$key1 = "";}

if (isset($key[1])){
   $key2=$key[1];                                  //Kunci Kedua
   $key2 = preg_replace("/[^a-z0-9]/", "", $key2); //hanya karakter a-z
}else {$key2 = "";}

if (isset($key[2])){
   $key3=$key[2];                                  //Kunci Ketiga
   $key3 = preg_replace("/[^a-z0-9]/", "", $key3); //hanya karakter a-z
}else {$key3 = "";}

if (isset($key[3])){
   $key4=$key[3];                                  //Kunci Ketiga
   $key4 = preg_replace("/[^a-z0-9]/", "", $key4); //hanya karakter a-z
}else {$key4 = "";}

if (isset($key[4])){
   $key5=$key[4];                                  //Kunci Ketiga
   $key5 = preg_replace("/[^a-z0-9]/", "", $key5); //hanya karakter a-z
}else {$key5 = "empty";}
$answer = "empty";

if (isset($key[5])){
   $key6=$key[5];                                  //Kunci Ketiga
   $key6 = preg_replace("/[^a-z0-9]/", "", $key6); //hanya karakter a-z
}else {$key6 = "empty";}
$answer = "empty";

if (isset($key[6])){
   $key7=$key[6];                                  //Kunci Ketiga
   $key7 = preg_replace("/[^a-z0-9]/", "", $key7); //hanya karakter a-z
}else {$key7 = "empty";}
$answer = "empty";

if (isset($key[7])){
   $key8=$key[7];                                  //Kunci Ketiga
   $key8 = preg_replace("/[^a-z0-9]/", "", $key8); //hanya karakter a-z
}else {$key8 = "";}
$answer = "empty";

if (isset($key[8])){
   $key9=$key[8];                                  //Kunci Ketiga
   $key9 = preg_replace("/[^a-z0-9]/", "", $key9); //hanya karakter a-z
}else {$key9 = "";}
$answer = "empty";

if (isset($key[9])){
   $key10=$key[9];                                  //Kunci Ketiga
   $key10 = preg_replace("/[^a-z0-9]/", "", $key10); //hanya karakter a-z
}else {$key10 = "";}
$answer = "empty";

if (isset($key[10])){
   $key11=$key[10];                                  //Kunci Ketiga
   $key11 = preg_replace("/[^a-z0-9]/", "", $key11); //hanya karakter a-z
}else {$key11 = "";}
$answer = "empty";

if (isset($key[11])){
   $key12=$key[11];                                  //Kunci Ketiga
   $key12 = preg_replace("/[^a-z0-9]/", "", $key12); //hanya karakter a-z
}else {$key12 = "";}
$answer = "empty";

if (isset($key[12])){
   $key13=$key[12];                                  //Kunci Ketiga
   $key13 = preg_replace("/[^a-z0-9]/", "", $key13); //hanya karakter a-z
}else {$key13 = "";}
$answer = "empty";

if (isset($key[13])){
   $key14=$key[13];                                  //Kunci Ketiga
   $key14 = preg_replace("/[^a-z0-9]/", "", $key14); //hanya karakter a-z
}else {$key14 = "";}
$answer = "empty";

if (isset($key[14])){
   $key15=$key[14];                                  //Kunci Ketiga
   $key15 = preg_replace("/[^a-z0-9]/", "", $key15); //hanya karakter a-z
}else {$key15 = "";}
$answer = "empty";

if (isset($key[15])){
   $key16=$key[15];                                  //Kunci Ketiga
   $key16 = preg_replace("/[^a-z0-9]/", "", $key16); //hanya karakter a-z
}else {$key16 = "";}
$answer = "empty";

?>
