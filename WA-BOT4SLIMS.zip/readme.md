======BOT WHATSAPP FOR SLIMS=======
Create by : ALAN BUDI KUSUMA
Email : masbudikusuma@gmail.com
Website : https://sites.google.com/view/masbudikusuma/product/wa-bot-slims-library
Contact Me : https://wa.me/6281217181715
--OpenDonate--

Bekerja dengan baik menggunakan aplikasi autoreply (Playstore)
Feature : BOT WHATSAPP for SLIM

Menu Umum :

- pencarian Buku berdasarkan judul, Pengarang dan Topik
- Melihat Detail Buku
- Melihat status Ketersedian Buku untuk dipinjam
- Sub Menu FAQ custom melalui database
- Kostum Jawab Langsung di edit melalui script PHP

MEnu member :

- melihat biodata di slims
- melihat buku yang sedang dipinjam
- melihat dendan buku yang sedang dipinjam
- melihat history Peminjaman

Menu ADMIN

- Melihat biodata member
- melihat buku yang sedang dipinjam member
- melihat denda peminjaman member
- melihat history peminjaman member
- Melihat Summary Peminjaman di SLIMS
