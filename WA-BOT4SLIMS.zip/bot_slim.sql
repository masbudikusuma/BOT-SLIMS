-- --------------------------------------------------------
-- Host:                         localhost
-- Server version:               5.7.24 - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Version:             11.3.0.6295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Dumping structure for table wa-checkbot.wa_admin
CREATE TABLE IF NOT EXISTS `wa_admin` (
  `userid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_number` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_created` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `date_update` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`userid`) USING BTREE,
  UNIQUE KEY `userid` (`userid`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- Dumping data for table wa-checkbot.wa_admin: 1 rows
/*!40000 ALTER TABLE `wa_admin` DISABLE KEYS */;
INSERT INTO `wa_admin` (`userid`, `name`, `email`, `phone_number`, `date_created`, `date_update`) VALUES
	(5, 'MasBudiKusuma', 'masbudikusuma@gmail.com', '6285640259748', '2020-10-14 14:20:36', '2021-09-20 16:16:46');
/*!40000 ALTER TABLE `wa_admin` ENABLE KEYS */;

-- Dumping structure for table wa-checkbot.wa_data_answer
CREATE TABLE IF NOT EXISTS `wa_data_answer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sender` text COLLATE utf8mb4_unicode_ci,
  `p_last` text COLLATE utf8mb4_unicode_ci,
  `nama` text COLLATE utf8mb4_unicode_ci,
  `prodi` text COLLATE utf8mb4_unicode_ci,
  `fakultas` text COLLATE utf8mb4_unicode_ci,
  `tanggal_lahir` text COLLATE utf8mb4_unicode_ci,
  `alamat` text COLLATE utf8mb4_unicode_ci,
  `id_member` text COLLATE utf8mb4_unicode_ci,
  `p7` text COLLATE utf8mb4_unicode_ci,
  `p8` text COLLATE utf8mb4_unicode_ci,
  `p9` text COLLATE utf8mb4_unicode_ci,
  `p10` text COLLATE utf8mb4_unicode_ci,
  `p11` text COLLATE utf8mb4_unicode_ci,
  `begin` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lastupdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ket` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=594 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table wa-checkbot.wa_data_answer: 0 rows
/*!40000 ALTER TABLE `wa_data_answer` DISABLE KEYS */;
/*!40000 ALTER TABLE `wa_data_answer` ENABLE KEYS */;

-- Dumping structure for table wa-checkbot.wa_faq
CREATE TABLE IF NOT EXISTS `wa_faq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` longtext COLLATE utf8mb4_unicode_ci,
  `question` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `used` longtext COLLATE utf8mb4_unicode_ci,
  `requestIN` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `id` (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- Dumping data for table wa-checkbot.wa_faq: 12 rows
/*!40000 ALTER TABLE `wa_faq` DISABLE KEYS */;
INSERT INTO `wa_faq` (`id`, `label`, `question`, `answer`, `used`, `requestIN`) VALUES
	(1, NULL, 'Layanan perpustakaan buka jam berapa ?', '*SENIN - JUMAT*\r\nBUKA JAM 08.00 - 17.00 WIB\r\nISTIR', 'yes', 0),
	(2, NULL, 'Layanan-layanan apa yang disediakan ?', 'Perpustakaan  memiliki beberapa jenis', 'yes', 0),
	(3, NULL, 'Apakah hari Sabtu tetap buka ?', 'Layanan Perpustakaan  sampai hari Sa', 'yes', 0),
	(4, NULL, 'Apakah Pengguna diluar civitas akademika bisa memanfaatkan koleksi perpustakaan ?', 'Layanan informasi perpustakaan bersifat terbuka un', 'yes', 0),
	(5, NULL, 'Berapa lama waktu peminjaman ?', 'Lama Peminjaman Buku Perpustakaan :\r\n1. Dosen : 1 ', 'yes', 0),
	(6, NULL, 'Berapa buku bisa dipinjam ?', 'Jumlah Buku yang boleh dipinjam :\r\n1. Dosen : 10 b', 'yes', 0),
	(7, NULL, 'Berapa denda keterlambatan per hari ?', 'Sesuai SK Rektor per 1 Maret 2017 tarif denda kete', 'yes', 0),
	(8, NULL, 'Berapa lama proses penerbitan surat bebas perpustakaan ?', 'Surat keterangan Bebas Perpustakaan akan diterbitk', 'yes', 0),
	(9, NULL, 'Bagaimana cara mengembalikan buku lewat bookdrop ?', 'Syarat pengembalian lewat book drop :\r\n1. Buku yan', 'yes', 0),
	(10, NULL, 'Bagaimana cara mendaftar anggota walisongo e-library ?', 'Cara mendaftar keanggotaan Walisongo E-Library :\r\n', 'yes', 0),
	(11, NULL, 'Bagaimana bila no. WA belum terdaftar di sistem ?', 'Silahkan update no kontak whatsapp anda melalui li', 'yes', 0),
	(12, NULL, 'Pertanyaan lain ?', 'Silahkan hubungan WA Admin  \r\nke nomor +62812 2920', 'yes', 0);
/*!40000 ALTER TABLE `wa_faq` ENABLE KEYS */;

-- Dumping structure for table wa-checkbot.wa_library
CREATE TABLE IF NOT EXISTS `wa_library` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` longtext COLLATE utf8mb4_unicode_ci,
  `question` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer` text COLLATE utf8mb4_unicode_ci,
  `used` longtext COLLATE utf8mb4_unicode_ci,
  `requestIN` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table wa-checkbot.wa_library: 0 rows
/*!40000 ALTER TABLE `wa_library` DISABLE KEYS */;
/*!40000 ALTER TABLE `wa_library` ENABLE KEYS */;

-- Dumping structure for table wa-checkbot.wa_message_in
CREATE TABLE IF NOT EXISTS `wa_message_in` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender` mediumtext,
  `message_in` mediumtext,
  `message_out` mediumtext,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `datein` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateapp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `app` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  FULLTEXT KEY `cari_nama` (`sender`,`message_in`,`message_out`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Dumping data for table wa-checkbot.wa_message_in: 0 rows
/*!40000 ALTER TABLE `wa_message_in` DISABLE KEYS */;
/*!40000 ALTER TABLE `wa_message_in` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
